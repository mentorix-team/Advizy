import ComingSoon from '@/ComingSoon'
import React from 'react'

const Chats = () => {
  return (
    <ComingSoon />
  )
}

export default Chats
